
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'ist8310' 
 * Target:  'INA226' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H



#endif /* RTE_COMPONENTS_H */
