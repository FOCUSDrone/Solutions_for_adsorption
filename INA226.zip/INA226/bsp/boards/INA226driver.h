
/**
  * @file       IST8310driver.c/h
  * @brief      ist8310 is a 3-axis digital magnetometer, the file includes initialization function,
  *             read magnetic field strength data function.
  * @note       IST8310 only support I2C
  * @history
  *  Version    Date            Author          Modification
  *  V1.0.0     Dec-26-2018     RM              1. ���
  *
  */


#include <inttypes.h>
#include <stdbool.h>

#if defined(USE_HAL_DRIVER)
#include "stm32f4xx_hal.h"
#endif

extern I2C_HandleTypeDef hi2c2;
#define I2C_HANDLE_IN226 hi2c2


struct INA226; 
struct INA226_Registers;
struct INA226_HardCodedChipConst;
struct INA226_DefaultSettings;

static const int INA226_I2C_TIMEOUT = 1000;


typedef enum {OK=0, FAIL=-1,
    INA226_TI_ID_MISMATCH = -2,
    INA226_DIE_ID_MISMATCH =-3,
    CONFIG_ERROR = -4,
    I2C_TRANSMISSION_ERROR = -5,
    BAD_PARAMETER = -6,
    NOT_INITIALIZED = -7,
    INVALID_I2C_ADDRESS} status;

typedef struct  INA226{
    bool     mInitialized;
    uint8_t  mI2C_Address;
    uint16_t mConfigRegister;        //local copy from the INA226
    uint16_t mCalibrationValue;        //local copy from the INA226
    int32_t  mCurrentMicroAmpsPerBit; //This is the Current_LSB, as defined in the INA266 spec
    int32_t  mPowerMicroWattPerBit;
}  INA226;

//=============================================================================

enum eOperatingMode {//Shutdown=0,
                    ShuntVoltageTriggered        = 1,
                    BusVoltageTriggered          = 2,
                    ShuntAndBusTriggered         = 3,
                    Shutdown                     = 4,
                    ShuntVoltageContinuous       = 5,
                    BusVoltageContinuous         = 6,
                    ShuntAndBusVoltageContinuous = 7}; //default

enum eAlertTrigger {ClearTriggers                = 0x0000, //default
                    ShuntVoltageOverLimit        = 0x8000,
                    ShuntVoltageUnderLimit       = 0x4000,
                    BusVoltageOverLimit          = 0x2000,
                    BusVoltageUnderLimit         = 0x1000,
                    PowerOverLimit               = 0x0800,
                    ConversionReady              = 0x0400};

enum eAlertTriggerCause{
                    Unknown=0,
                    AlertFunctionFlag            = 0x10,
                    ConversionReadyFlag          = 0x08,
                    MathOverflowFlag             = 0x04,
                    AlertPolarityBit             = 0x02};
//=============================================================================

/**
  * @brief          
  * @param[in]      
  * @retval         
  */
/**
  * @brief          
  * @param[in]     
  * @retval         
  */
void  INA226_Constructor( INA226*);
/** 
  * @param[in]      
  * @retval         
  */
/**
  * @brief          
  * @param[in]     
  * @retval         
  */
	
status  INA226_CheckI2cAddress(uint8_t aI2C_Address);
/**
  * @brief          
  * @param[in]      
  * @retval         
  */
/**
  * @brief          
  * @param[in]     
  * @retval         
  */
//Resets the INA226 and configures it according to the supplied parameters - should be called first.
//status  INA226_Init(uint8_t aI2C_Address=0x40, double aShuntResistor_Ohms=0.1, double aMaxCurrent_Amps=3.2767);
status  INA226_Init( INA226*,uint8_t aI2C_Address, double aShuntResistor_Ohms, double aMaxCurrent_Amps);
/**
  * @brief          
  * @param[in]      
  * @retval         
  */
/**
  * @brief          
  * @param[in]     
  * @retval         
  */
int32_t  INA226_GetShuntVoltage_uV( INA226*);
int32_t  INA226_GetBusVoltage_uV( INA226*);
int32_t  INA226_GetCurrent_uA( INA226*);
int32_t  INA226_GetPower_uW( INA226*);
/**
  * @brief          
  * @param[in]      
  * @retval         
  */
/**
  * @brief          
  * @param[in]     
  * @retval         
  */
status  INA226_SetOperatingMode( INA226*,enum eOperatingMode aOpMode);
status  INA226_Hibernate( INA226*); //Enters a very low power mode, no voltage measurements
status  INA226_Wakeup( INA226*);    //Wake-up and enter the last operating mode

//The trigger value is in microwatts or microvolts, depending on the trigger
status  INA226_ConfigureAlertPinTrigger( INA226*,enum eAlertTrigger aAlertTrigger, int32_t aValue, bool aLatching);
//status  INA226_ResetAlertPin( INA226*);
status  INA226_ResetAlertPin( INA226*,enum  eAlertTriggerCause* aAlertTriggerCause_p ); //provides feedback as to what caused the alert

//The parameters for the two functions below are indices into the tables defined in the INA226 spec
//These tables are copied below for your information (caNumSamplesAveraged & caVoltageConvTimeMicroSecs)
status  INA226_ConfigureVoltageConversionTime( INA226*,int aIndexToConversionTimeTable);
status  INA226_ConfigureNumSampleAveraging( INA226*,int aIndexToSampleAverageTable);
status  INA226_Debug_GetConfigRegister( INA226*,uint16_t* aConfigReg_p);

//Private functions

status  INA226_WriteRegister( INA226*,uint8_t aRegister, uint16_t aValue);
status  INA226_ReadRegister( INA226*,uint8_t aRegister, uint16_t* aValue_p);
status  INA226_setupCalibration( INA226*,double aShuntResistor_Ohms, double aMaxCurrent_Amps);


