#ifndef PRESS_H_
#define PRESS_H_

#include "main.h"

void calibrate_zero_point(void);
uint32_t get_pressure(void) ;
void pressure_sensor_init(void);

#endif
