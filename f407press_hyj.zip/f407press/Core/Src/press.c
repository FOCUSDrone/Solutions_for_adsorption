#include "main.h"
#include "i2c.h"

#define PRESS_W_ADDRESS (0x6D << 1)
#define PRESS_R_ADDRESS ((0x6D << 1)|0x01)
#define K_VALUE         64    // 0~200kPa����
#define OSR_CONFIG      0x07   // 32768X������

static int32_t pressure_offset = 0;

// 24λ�з�������չ
int32_t sign_extend_24(uint32_t x) {
    return (x & 0x00800000) ? (x | 0xFF000000) : x;
}

// ��������ʼ��
void  pressure_sensor_init() {
    // ���ø߾���ģʽ
    uint8_t cfg = OSR_CONFIG;
    HAL_I2C_Mem_Write(&hi2c2, PRESS_W_ADDRESS, 0xA6, 
                      I2C_MEMADD_SIZE_8BIT, &cfg, 1, 10000);
    
    // ������������
    uint8_t cmd = 0x1B; // 62.5ms���
    HAL_I2C_Mem_Write(&hi2c2, PRESS_W_ADDRESS, 0x30,
                     I2C_MEMADD_SIZE_8BIT, &cmd, 1, 10000);
}

// У׼��㣨�ڴ���ѹ�����µ��ã�
void calibrate_zero_point() {
    const uint8_t samples = 30;
    int64_t sum = 0;
    
    for(uint8_t i=0; i<samples; i++){
        uint8_t data[3];
        HAL_I2C_Mem_Read(&hi2c2, PRESS_R_ADDRESS, 0x06,
                        I2C_MEMADD_SIZE_8BIT, data, 3, 10000);
        sum += sign_extend_24((data[0]<<16)|(data[1]<<8)|data[2]);
//        HAL_Delay(50);
    }
    pressure_offset = sum / samples;
}

// ��ȡѹ������ֵ��Pa��
uint32_t get_pressure() {
    uint8_t data[3];
    HAL_I2C_Mem_Read(&hi2c2, PRESS_R_ADDRESS, 0x06,
                    I2C_MEMADD_SIZE_8BIT, data, 3, 10000);
    
    int32_t raw = sign_extend_24((data[0]<<16)|(data[1]<<8)|data[2]);
    int32_t p = (raw - pressure_offset) / K_VALUE;
    
    return (p >= 0) ? p : -p;
}